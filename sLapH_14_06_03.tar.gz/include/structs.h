#ifndef STRUCTS_H
#define STRUCTS_H

//struct to hold results
struct shp {

  Eigen::RowVector3i r;
  double length;
  double shape;

};

#endif //STRUCTS_H
